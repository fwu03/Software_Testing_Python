from distutils.core import setup

setup(name='mlist',
      version='0.1',
      description='Finding Prime Numbers in Lists',
      author='Bailey Lei, Fan Wu, Daniel Lin',
      author_email='email@email.net',
      url='https://github.com/UBC-MDS/mlist_Python',
      packages=['mlist',],
     )